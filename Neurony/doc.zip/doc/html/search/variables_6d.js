var searchData=
[
  ['momentum',['momentum',['../classneurons_1_1_gradient_descent_trainer.html#a6f3adf4058a0897b2abc8bce27b86840',1,'neurons.GradientDescentTrainer.momentum()'],['../classneurons_1_1_neuron_trainer.html#a896788240bf0b2e61149b888360020fa',1,'neurons.NeuronTrainer.momentum()']]]
];
