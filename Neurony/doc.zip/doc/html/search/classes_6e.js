var searchData=
[
  ['neuron',['Neuron',['../classneurons_1_1_neuron.html',1,'neurons']]],
  ['neuronlayer',['NeuronLayer',['../classneurons_1_1layers_1_1_neuron_layer.html',1,'neurons::layers']]],
  ['neurontrainer',['NeuronTrainer',['../classneurons_1_1_neuron_trainer.html',1,'neurons']]],
  ['neurontrainexception',['NeuronTrainException',['../classexceptions_1_1_neuron_train_exception.html',1,'exceptions']]]
];
