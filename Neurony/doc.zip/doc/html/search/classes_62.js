var searchData=
[
  ['badvectordimensionexception',['BadVectorDimensionException',['../classexceptions_1_1_bad_vector_dimension_exception.html',1,'exceptions']]]
];
