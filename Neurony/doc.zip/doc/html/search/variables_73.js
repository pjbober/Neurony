var searchData=
[
  ['serialversionuid',['serialVersionUID',['../classexceptions_1_1_bad_vector_dimension_exception.html#a8d083a191b1a1ee57b03a7caf98962a1',1,'exceptions.BadVectorDimensionException.serialVersionUID()'],['../classexceptions_1_1_neuron_train_exception.html#a137dd40e771b9efab6ea7907af997455',1,'exceptions.NeuronTrainException.serialVersionUID()']]],
  ['sigmoid',['Sigmoid',['../enumactivationfunction_1_1_activation_functions.html#ae9b6f3243899c26b93bbc249024f8f16',1,'activationfunction::ActivationFunctions']]]
];
