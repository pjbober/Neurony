var searchData=
[
  ['gradientdescenttrainer',['GradientDescentTrainer',['../classneurons_1_1_gradient_descent_trainer.html',1,'neurons']]]
];
