var searchData=
[
  ['network',['network',['../classneurons_1_1_gradient_descent_trainer.html#a008170dd34c6a29e10ec7cfaa17e0679',1,'neurons::GradientDescentTrainer']]],
  ['neuron',['neuron',['../classneurons_1_1_neuron_trainer.html#a2edabd0573771758c04170a34551d99a',1,'neurons::NeuronTrainer']]],
  ['neurons',['neurons',['../classneurons_1_1layers_1_1_neuron_layer.html#ad901d2f6c54ddd14c5932ee236ca5059',1,'neurons::layers::NeuronLayer']]],
  ['nrofhiddenlayers',['nrOfHiddenLayers',['../classneurons_1_1_feed_forward_net_creator.html#a180010a0ac9b845f7fa9396aa9ba9334',1,'neurons::FeedForwardNetCreator']]],
  ['nrofinputperneuron',['nrOfInputPerNeuron',['../classneurons_1_1layers_1_1_neuron_layer.html#a802dba9065fea1a03b680e836519f56d',1,'neurons::layers::NeuronLayer']]],
  ['nrofinputs',['nrOfInputs',['../classneurons_1_1_feed_forward_net_creator.html#ae6fa072a4e8b19c17b76e61976081065',1,'neurons.FeedForwardNetCreator.nrOfInputs()'],['../classneurons_1_1_neuron.html#a8bc9a8021809483e0486ada23a0ffba8',1,'neurons.Neuron.nrOfInputs()']]],
  ['nrofneurons',['nrOfNeurons',['../classneurons_1_1layers_1_1_neuron_layer.html#aa59a8b2812052b3404ced671daa42bed',1,'neurons::layers::NeuronLayer']]],
  ['nrofneuronsinhiddenlayers',['nrOfNeuronsInHiddenLayers',['../classneurons_1_1_feed_forward_net_creator.html#a0b6e1d2a6cc2f7ec30c44d9e3b4162b6',1,'neurons::FeedForwardNetCreator']]],
  ['nrofoutputs',['nrOfOutputs',['../classneurons_1_1_feed_forward_net_creator.html#a84202a635bc0ec6968f1ee0097232921',1,'neurons::FeedForwardNetCreator']]]
];
