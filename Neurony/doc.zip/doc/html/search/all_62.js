var searchData=
[
  ['badvectordimensionexception',['BadVectorDimensionException',['../classexceptions_1_1_bad_vector_dimension_exception.html',1,'exceptions']]],
  ['badvectordimensionexception',['BadVectorDimensionException',['../classexceptions_1_1_bad_vector_dimension_exception.html#a8ff363cb2101e32f3b9c14225ea9d7fb',1,'exceptions.BadVectorDimensionException.BadVectorDimensionException()'],['../classexceptions_1_1_bad_vector_dimension_exception.html#ab4f4566992eae430198c9dbb2e4d6c92',1,'exceptions.BadVectorDimensionException.BadVectorDimensionException(String string)']]],
  ['badvectordimensionexception_2ejava',['BadVectorDimensionException.java',['../_bad_vector_dimension_exception_8java.html',1,'']]],
  ['bias',['bias',['../classneurons_1_1_neuron.html#a0aecdabbfaf55e44b754736fd3360620',1,'neurons::Neuron']]],
  ['build',['build',['../classneurons_1_1_feed_forward_net_creator.html#ac88522c756a08ff8b9946e7ab3022256',1,'neurons::FeedForwardNetCreator']]],
  ['builder',['builder',['../classneurons_1_1_feed_forward_net_creator.html#a3aa2b9c142a3ca3fb40873a569aec0f0',1,'neurons::FeedForwardNetCreator']]]
];
