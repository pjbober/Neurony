var searchData=
[
  ['activationfunction',['ActivationFunction',['../interfaceactivationfunction_1_1_activation_function.html',1,'activationfunction']]],
  ['activationfunction',['activationfunction',['../namespaceactivationfunction.html',1,'activationfunction'],['../classneurons_1_1_neuron.html#a042155fe2ec8b75dc3fb73537dea6b1b',1,'neurons.Neuron.activationFunction()']]],
  ['activationfunction_2ejava',['ActivationFunction.java',['../_activation_function_8java.html',1,'']]],
  ['activationfunctionderiv',['ActivationFunctionDeriv',['../interfaceactivationfunction_1_1_activation_function_deriv.html',1,'activationfunction']]],
  ['activationfunctionderiv_2ejava',['ActivationFunctionDeriv.java',['../_activation_function_deriv_8java.html',1,'']]],
  ['activationfunctions',['activationFunctions',['../classneurons_1_1_feed_forward_net_creator.html#ad9313a5133c7f60eef527173c3ab8d8b',1,'neurons.FeedForwardNetCreator.activationFunctions()'],['../enumactivationfunction_1_1_activation_functions.html#a8f46972be13cc3a30905d50d09b6f9a1',1,'activationfunction.ActivationFunctions.ActivationFunctions()']]],
  ['activationfunctions',['ActivationFunctions',['../enumactivationfunction_1_1_activation_functions.html',1,'activationfunction']]],
  ['activationfunctions_2ejava',['ActivationFunctions.java',['../_activation_functions_8java.html',1,'']]],
  ['adjustweights',['adjustWeights',['../classneurons_1_1_gradient_descent_trainer.html#aa137d94f2e41eee4b73344e127b68db9',1,'neurons::GradientDescentTrainer']]],
  ['arraysutil',['ArraysUtil',['../classutils_1_1_arrays_util.html',1,'utils']]],
  ['arraysutil_2ejava',['ArraysUtil.java',['../_arrays_util_8java.html',1,'']]],
  ['impl',['impl',['../namespaceactivationfunction_1_1impl.html',1,'activationfunction']]]
];
