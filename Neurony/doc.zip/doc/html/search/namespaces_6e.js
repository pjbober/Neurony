var searchData=
[
  ['layers',['layers',['../namespaceneurons_1_1layers.html',1,'neurons']]],
  ['neurons',['neurons',['../namespaceneurons.html',1,'']]]
];
