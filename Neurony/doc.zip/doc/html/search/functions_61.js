var searchData=
[
  ['activationfunctions',['ActivationFunctions',['../enumactivationfunction_1_1_activation_functions.html#a8f46972be13cc3a30905d50d09b6f9a1',1,'activationfunction::ActivationFunctions']]],
  ['adjustweights',['adjustWeights',['../classneurons_1_1_gradient_descent_trainer.html#aa137d94f2e41eee4b73344e127b68db9',1,'neurons::GradientDescentTrainer']]]
];
