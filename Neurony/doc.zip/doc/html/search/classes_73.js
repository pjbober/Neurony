var searchData=
[
  ['sigmoidactivationfunction',['SigmoidActivationFunction',['../classactivationfunction_1_1_sigmoid_activation_function.html',1,'activationfunction']]],
  ['sigmoidactivationfunction',['SigmoidActivationFunction',['../classactivationfunction_1_1impl_1_1_sigmoid_activation_function.html',1,'activationfunction::impl']]]
];
