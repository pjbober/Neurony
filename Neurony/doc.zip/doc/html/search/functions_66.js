var searchData=
[
  ['feedforwardnet',['FeedForwardNet',['../classneurons_1_1_feed_forward_net.html#a432bdb0087c036b53e8fe2d51a1a4c1a',1,'neurons::FeedForwardNet']]],
  ['feedforwardnetcreator',['FeedForwardNetCreator',['../classneurons_1_1_feed_forward_net_creator.html#abbdd2c07d54673c4ffd7f479638cd994',1,'neurons::FeedForwardNetCreator']]]
];
