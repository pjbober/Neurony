var searchData=
[
  ['setepochs',['setEpochs',['../classneurons_1_1_gradient_descent_trainer.html#ac21f0737a34067c0d5c745f09b063ac0',1,'neurons::GradientDescentTrainer']]],
  ['seterror',['setError',['../classneurons_1_1_neuron.html#a33b7b493a748f3831a10fa51b3db2acc',1,'neurons::Neuron']]],
  ['setlearningrate',['setLearningRate',['../classneurons_1_1_gradient_descent_trainer.html#a26771af606021880f9af2accba4125c1',1,'neurons.GradientDescentTrainer.setLearningRate()'],['../classneurons_1_1_neuron_trainer.html#ab55c48720bda1760eb1b47dfb1070015',1,'neurons.NeuronTrainer.setLearningRate()']]],
  ['setmomentum',['setMomentum',['../classneurons_1_1_gradient_descent_trainer.html#a2191e76de0bfb3edc9a452815c19054c',1,'neurons.GradientDescentTrainer.setMomentum()'],['../classneurons_1_1_neuron_trainer.html#a25f906f023e4db9b1635c82c30eb172c',1,'neurons.NeuronTrainer.setMomentum()']]],
  ['setnetwork',['setNetwork',['../classneurons_1_1_gradient_descent_trainer.html#ad9c416d47a17b15f4d9c5ba6caa49d7f',1,'neurons::GradientDescentTrainer']]],
  ['setpreviousweights',['setPreviousWeights',['../classneurons_1_1_neuron.html#a5818dbaeb5192b80070f32d03b126e6e',1,'neurons::Neuron']]]
];
