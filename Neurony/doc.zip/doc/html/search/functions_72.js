var searchData=
[
  ['readresolve',['readResolve',['../classneurons_1_1_neuron.html#a232d68466d9fa766ad2530370fcbe1a8',1,'neurons::Neuron']]]
];
