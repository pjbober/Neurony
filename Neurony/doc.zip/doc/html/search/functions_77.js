var searchData=
[
  ['withactivationfunctioninhiddenlayer',['withActivationFunctionInHiddenLayer',['../classneurons_1_1_feed_forward_net_creator.html#a1c91a9d667e313ae8dece4731e5b452e',1,'neurons::FeedForwardNetCreator']]],
  ['withnrofinputs',['withNrOfInputs',['../classneurons_1_1_feed_forward_net_creator.html#a46c4edd80230768b4445da17454ab1c9',1,'neurons::FeedForwardNetCreator']]],
  ['withnrofoutputs',['withNrOfOutputs',['../classneurons_1_1_feed_forward_net_creator.html#aefaf529b4210b2bd6ee5a85ebd49feab',1,'neurons::FeedForwardNetCreator']]],
  ['withnumberofneuronsinhiddenlayer',['withNumberOfNeuronsInHiddenLayer',['../classneurons_1_1_feed_forward_net_creator.html#a57d3e9ca2f0da73db0196c63e3e94e16',1,'neurons::FeedForwardNetCreator']]],
  ['withoutputactivationfunction',['withOutputActivationFunction',['../classneurons_1_1_feed_forward_net_creator.html#a10f8a6ee5b69831c2e109abb235ab318',1,'neurons::FeedForwardNetCreator']]],
  ['withsameactivationfunction',['withSameActivationFunction',['../classneurons_1_1_feed_forward_net_creator.html#a5e831fe72b3aa361acbcecfef8e39344',1,'neurons::FeedForwardNetCreator']]],
  ['withsamenumberofneuronsinlayers',['withSameNumberOfNeuronsInLayers',['../classneurons_1_1_feed_forward_net_creator.html#a236fa992ac995d35af2445da95ad5884',1,'neurons::FeedForwardNetCreator']]]
];
