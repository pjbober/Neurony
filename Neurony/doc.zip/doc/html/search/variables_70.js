var searchData=
[
  ['previousweights',['previousWeights',['../classneurons_1_1_neuron.html#ac5e1529adfbd82adf573447f0e4c5a68',1,'neurons::Neuron']]]
];
