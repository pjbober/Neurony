var searchData=
[
  ['layers',['layers',['../classneurons_1_1_feed_forward_net.html#ac785323abf90e00e15bec14a4f44697d',1,'neurons::FeedForwardNet']]],
  ['learningrate',['learningRate',['../classneurons_1_1_gradient_descent_trainer.html#ae22d22bbb572b667198dffa297d7d8af',1,'neurons.GradientDescentTrainer.learningRate()'],['../classneurons_1_1_neuron_trainer.html#ae9236f285d6da9a7b79ceab35a069353',1,'neurons.NeuronTrainer.learningRate()']]],
  ['linear',['Linear',['../enumactivationfunction_1_1_activation_functions.html#abe674b473fb8221d3ee37f0d1fe874cf',1,'activationfunction::ActivationFunctions']]]
];
