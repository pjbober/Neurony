var searchData=
[
  ['feedforwardnet',['FeedForwardNet',['../classneurons_1_1_feed_forward_net.html',1,'neurons']]],
  ['feedforwardnetcreator',['FeedForwardNetCreator',['../classneurons_1_1_feed_forward_net_creator.html',1,'neurons']]]
];
