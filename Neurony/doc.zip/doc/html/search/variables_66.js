var searchData=
[
  ['function',['function',['../classneurons_1_1_neuron.html#a1e299371e8acc310f697434c5b2e72ea',1,'neurons::Neuron']]],
  ['functionclass',['functionClass',['../enumactivationfunction_1_1_activation_functions.html#a0cfd9bcd9691288ef23ae9b618d39df8',1,'activationfunction::ActivationFunctions']]]
];
