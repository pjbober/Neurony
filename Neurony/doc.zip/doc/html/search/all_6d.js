var searchData=
[
  ['main',['Main',['../class_main.html',1,'Main'],['../class_main.html#a8a5d0f827edddff706cc0e6740d0579a',1,'Main.main()']]],
  ['main_2ejava',['Main.java',['../_main_8java.html',1,'']]],
  ['modifybiasby',['modifyBiasBy',['../classneurons_1_1_neuron.html#a194ecacfe57c85ba8d1525f5a45dbdeb',1,'neurons::Neuron']]],
  ['modifyweightsby',['modifyWeightsBy',['../classneurons_1_1_neuron.html#abfb76be375e372c7a3ce7a090838f5ee',1,'neurons::Neuron']]],
  ['momentum',['momentum',['../classneurons_1_1_gradient_descent_trainer.html#a6f3adf4058a0897b2abc8bce27b86840',1,'neurons.GradientDescentTrainer.momentum()'],['../classneurons_1_1_neuron_trainer.html#a896788240bf0b2e61149b888360020fa',1,'neurons.NeuronTrainer.momentum()']]],
  ['multiply',['multiply',['../classutils_1_1_vectors.html#a181b5392c174e4e182ef3306bd4150b2',1,'utils.Vectors.multiply(double[] vector1, double[] vector2)'],['../classutils_1_1_vectors.html#a0d038ea99b763ad7ca754a1628eff18f',1,'utils.Vectors.multiply(double[] input, double delta)']]],
  ['multiplyarray',['multiplyArray',['../classutils_1_1_arrays_util.html#a31f8f70093e389902326637d3c0253a8',1,'utils::ArraysUtil']]],
  ['multiplybiasby',['multiplyBiasBy',['../classneurons_1_1_neuron.html#a4b5ce85a05adeb8c270f345d627e7d50',1,'neurons::Neuron']]],
  ['multiplyweightby',['multiplyWeightBy',['../classneurons_1_1_neuron.html#a69bdac8fda8369837460ea5ebf373f7b',1,'neurons::Neuron']]]
];
