var searchData=
[
  ['activationfunction',['activationFunction',['../classneurons_1_1_neuron.html#a042155fe2ec8b75dc3fb73537dea6b1b',1,'neurons::Neuron']]],
  ['activationfunctions',['activationFunctions',['../classneurons_1_1_feed_forward_net_creator.html#ad9313a5133c7f60eef527173c3ab8d8b',1,'neurons::FeedForwardNetCreator']]]
];
