var searchData=
[
  ['sigmoidactivationfunction_2ejava',['SigmoidActivationFunction.java',['../impl_2_sigmoid_activation_function_8java.html',1,'']]],
  ['sigmoidactivationfunction_2ejava',['SigmoidActivationFunction.java',['../_sigmoid_activation_function_8java.html',1,'']]]
];
