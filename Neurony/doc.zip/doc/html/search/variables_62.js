var searchData=
[
  ['bias',['bias',['../classneurons_1_1_neuron.html#a0aecdabbfaf55e44b754736fd3360620',1,'neurons::Neuron']]]
];
