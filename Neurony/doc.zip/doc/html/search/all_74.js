var searchData=
[
  ['t',['t',['../classutils_1_1_pair_3_01_t_00_01_v_01_4.html#a05c8c7343c43b8e6ba51381bacde6854',1,'utils::Pair&lt; T, V &gt;']]],
  ['tostring',['toString',['../classneurons_1_1layers_1_1_neuron_layer.html#a4c2b2d99a7155a07b31c28ee1d453372',1,'neurons.layers.NeuronLayer.toString()'],['../classutils_1_1_arrays_util.html#a827ee4306aa597ea6ed8d88f3faa3c2c',1,'utils.ArraysUtil.toString()']]],
  ['train',['train',['../classneurons_1_1_gradient_descent_trainer.html#ae6bb9f8d2d638b6be70cfe2e0d750d59',1,'neurons.GradientDescentTrainer.train()'],['../classneurons_1_1_neuron_trainer.html#a2a83b72545dfc7bdf2486028bbe296c1',1,'neurons.NeuronTrainer.train()']]]
];
