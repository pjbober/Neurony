var searchData=
[
  ['exceptions',['exceptions',['../namespaceexceptions.html',1,'']]]
];
