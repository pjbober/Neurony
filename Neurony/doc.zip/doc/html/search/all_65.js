var searchData=
[
  ['epochs',['epochs',['../classneurons_1_1_gradient_descent_trainer.html#af5fb10147a17d421658a27677fbfb405',1,'neurons.GradientDescentTrainer.epochs()'],['../classneurons_1_1_neuron_trainer.html#ad81c5ff4d6b09709e7194f9b04516a51',1,'neurons.NeuronTrainer.epochs()']]],
  ['error',['error',['../classneurons_1_1_neuron.html#a4945bf427ee96f3133eaef67548797ce',1,'neurons::Neuron']]],
  ['exceptions',['exceptions',['../namespaceexceptions.html',1,'']]]
];
